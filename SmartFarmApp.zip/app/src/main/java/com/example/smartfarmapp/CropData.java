package com.example.smartfarmapp;

public class CropData {
        private String CropName;
        private String CropImageUrl;
        private String CropType;
        private int CropHighTemp;
        private int CropLowTemp;
        private int CropHighHum;
        private int CropLowHum;
        private int CropSoilHum;

        public void setCropName(String Name){
            this.CropName = Name;
        }
        public void setCropImageUrl(String Url){
            this.CropImageUrl = Url;
        }
        public void setCropType(String Type){
            this.CropType = Type;
        }
        public void setCropHighTemp(int HighTemp){
            this.CropHighTemp = HighTemp;
        }
        public void setCropLowTemp(int LowTemp){
        this.CropLowTemp = LowTemp;
    }
        public void setCropHighHum(int HighHum){
            this.CropHighHum = HighHum;
        }
        public void setCropLowHum(int LowHum){
        this.CropLowHum = LowHum;
    }
        public void setCropSoilHum(int SoilHum){
            this.CropSoilHum = SoilHum;
        }

        public String getCropName(){
            return CropName;
        }
        public String getCropImageUrl(){
            return CropImageUrl;
        }
        public String getCropType(){
            return CropType;
        }
        public int getCropHighTemp(){
            return CropHighTemp;
        }
        public int getCropHighHum(){
            return CropHighHum;
        }
        public int getCropLowTemp(){
        return CropLowTemp;
    }
        public int getCropLowHum(){
        return CropLowHum;
    }
        public int getCropSoilHum(){
            return CropSoilHum;
        }
}
