package com.example.smartfarmapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SaveDB extends SQLiteOpenHelper {

    public SaveDB(Context context){
        super(context, "SaveDB", null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table Save (_id integer primary key autoincrement, Name text, Image text, Type text, HighTemp integer, LowTemp integer, HighHum integer, LowHum integer, FarmSoilHum integer);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i2){
    }
}
