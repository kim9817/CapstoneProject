package com.example.smartfarmapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;


import android.app.Activity;
import android.content.Context;
import android.hardware.lights.Light;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Timer;
import java.util.TimerTask;

public class SensorActivity extends AppCompatActivity {

    TextView tempText;
    TextView humText;
    TextView SoilMosText;

    ImageView CamImage;

    Button LedButton;
    Button FanButton;
    Button WaterButton;

    int led = 0;
    int fan = 0;

    int set = 1;

    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference InTemp = database.getReference("InTemp");
    DatabaseReference InHum = database.getReference("InHum");
    DatabaseReference SoilMos = database.getReference("SoilMos");
    DatabaseReference Light = database.getReference("Light");
    DatabaseReference Fan = database.getReference("Fan");
    DatabaseReference Water = database.getReference("Water");
    DatabaseReference SetMode = database.getReference("Mode");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor);

        CamImage = findViewById(R.id.CamImage);
        tempText = findViewById(R.id.SensorTempText);
        humText = findViewById(R.id.SensorHumText);
        SoilMosText = findViewById(R.id.SensorSoilMosText);

        LedButton = findViewById(R.id.LedButton);
        FanButton = findViewById(R.id.FanButton);
        WaterButton = findViewById(R.id.WaterButton);

        Timer timer = new Timer();
        Timer timer2 = new Timer();


        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                storageRef.child("image.jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Glide.with(getApplicationContext())
                                .load(uri)
                                .placeholder(CamImage.getDrawable())
                                .into(CamImage);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        Toast.makeText(SensorActivity.this, "카메라 연결을 확인해주세요", Toast.LENGTH_SHORT).show();
                    }
                });

            }
        };
        timer.schedule(timerTask, 0, 100);

        TimerTask timerTask1 = new TimerTask() {
            @Override
            public void run() {
                if(set == 1) {
                    SetMode.setValue(1);
                }
            }
        };
        timer2.schedule(timerTask1,0 ,1000);


        InTemp.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                tempText.setText(Integer.toString(value) + "°C");
            }

            @Override
            public void onCancelled(DatabaseError error) {
                tempText.setText("D/C");
            }
        });

        InHum.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                humText.setText(Integer.toString(value) + "%");
            }

            @Override
            public void onCancelled(DatabaseError error) {
                humText.setText("D/C");
            }
        });

        SoilMos.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                SoilMosText.setText(Integer.toString(value) + "%");
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        Light.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                led = snapshot.getValue(int.class);
                if (led == 0) {
                    LedButton.setText("LED ON");
                } else {
                    LedButton.setText("LED OFF");
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        Fan.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                fan = snapshot.getValue(int.class);
                if (fan == 0) {
                    FanButton.setText("FAN ON");
                } else {
                    FanButton.setText("FAN OFF");
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        LedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (led == 0) {
                    Light.setValue(1);
                } else {
                    Light.setValue(0);
                }
            }
        });

        FanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fan == 0) {
                    Fan.setValue(1);
                } else {
                    Fan.setValue(0);
                }
            }
        });

        WaterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Water.setValue(1);
            }
        });



    } //Oncreate

    @Override
    public void onBackPressed(){
        SetMode.setValue(0);
        set = 0;
        finish();
    }

    @Override
    public void onPause(){
        super.onPause();
        SetMode.setValue(0);
        set = 0;
        Toast.makeText(SensorActivity.this, "자동제어를 시작합니다.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStop(){
        super.onStop();
        SetMode.setValue(0);
        set = 0;
    }

    @Override
    public void onResume(){
        super.onResume();
        SetMode.setValue(1);
        set = 1;
        Toast.makeText(SensorActivity.this, "수동제어를 시작합니다.", Toast.LENGTH_SHORT).show();
    }
}