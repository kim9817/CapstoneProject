package com.example.smartfarmapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class SelectCrop extends AppCompatActivity {

    RecyclerView LeafyListView;
    ArrayList<CropData> Clist;

    RecyclerView FruitListView;
    ArrayList<CropData> Flist;

    RecyclerView HerbListView;
    ArrayList<CropData> Hlist;

    RecyclerCropAdapter recyclerCropAdapter;
    RecyclerCropAdapter recyclerCropAdapter_Fruit;
    RecyclerCropAdapter recyclerCropAdapter_Herb;

    Button LeafyButton;
    Button FruitVegeButton;
    Button HerbButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_crop);
        firstInit();
        secondInit();
        thirdInit();

        LeafyButton = findViewById(R.id.LeafyButton);
        FruitVegeButton = findViewById(R.id.FruitVegeButton);
        HerbButton = findViewById(R.id.HerbButton);

        recyclerCropAdapter = new RecyclerCropAdapter(Clist);
        LeafyListView.setAdapter(recyclerCropAdapter);
        LeafyListView.setLayoutManager(new LinearLayoutManager(this));
        LeafyListView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        recyclerCropAdapter = new RecyclerCropAdapter(Flist);
        FruitListView.setAdapter(recyclerCropAdapter);
        FruitListView.setLayoutManager(new LinearLayoutManager(this));
        FruitListView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        recyclerCropAdapter_Herb = new RecyclerCropAdapter(Hlist);
        HerbListView.setAdapter(recyclerCropAdapter_Herb);
        HerbListView.setLayoutManager(new LinearLayoutManager(this));
        HerbListView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        CropDB helper = new CropDB(this);
        SQLiteDatabase Cropdb = helper.getWritableDatabase();
        String sql = "select * from Crop where Type = '엽채류';";
        Cursor cursor = Cropdb.rawQuery(sql, null);
        while (cursor.moveToNext()){
            String Name = cursor.getString(1);
            String Image = cursor.getString(2);
            String Type = cursor.getString(3);
            int HTemp = cursor.getInt(4);
            int LTemp = cursor.getInt(5);
            int HHum = cursor.getInt(6);
            int LHum = cursor.getInt(7);
            int SoilHum = cursor.getInt(8);
            addItem_Leafy(Name, Type, HTemp, LTemp, HHum, LHum, SoilHum, Image);
        }

        sql = "select * from Crop where Type = '허브';";
        cursor = Cropdb.rawQuery(sql, null);
        while (cursor.moveToNext()){
            String Name = cursor.getString(1);
            String Image = cursor.getString(2);
            String Type = cursor.getString(3);
            int HTemp = cursor.getInt(4);
            int LTemp = cursor.getInt(5);
            int HHum = cursor.getInt(6);
            int LHum = cursor.getInt(7);
            int SoilHum = cursor.getInt(8);
            addItem_Herb(Name, Type, HTemp, LTemp, HHum, LHum, SoilHum, Image);
        }

        sql = "select * from Crop where Type = '과채류';";
        cursor = Cropdb.rawQuery(sql, null);
        while (cursor.moveToNext()){
            String Name = cursor.getString(1);
            String Image = cursor.getString(2);
            String Type = cursor.getString(3);
            int HTemp = cursor.getInt(4);
            int LTemp = cursor.getInt(5);
            int HHum = cursor.getInt(6);
            int LHum = cursor.getInt(7);
            int SoilHum = cursor.getInt(8);
            addItem_Fruit(Name, Type, HTemp, LTemp, HHum, LHum, SoilHum, Image);
        }
        LeafyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LeafyListView.setVisibility(View.VISIBLE);
                FruitListView.setVisibility(View.INVISIBLE);
                HerbListView.setVisibility(View.INVISIBLE);
            }
        });

        FruitVegeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LeafyListView.setVisibility(View.INVISIBLE);
                FruitListView.setVisibility(View.VISIBLE);
                HerbListView.setVisibility(View.INVISIBLE);
            }
        });


        HerbButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LeafyListView.setVisibility(View.INVISIBLE);
                FruitListView.setVisibility(View.INVISIBLE);
                HerbListView.setVisibility(View.VISIBLE);
            }
        });
    }//Oncreate



    public void firstInit() {
        LeafyListView = (RecyclerView) findViewById(R.id.LeafyListView);
        Clist = new ArrayList<>();
    }

    public void secondInit() {
        HerbListView = (RecyclerView) findViewById(R.id.HerbListView);
        Hlist = new ArrayList<>();
    }
    public void thirdInit() {
        FruitListView = (RecyclerView) findViewById(R.id.FruitListView);
        Flist = new ArrayList<>();
    }

    public void addItem_Leafy(String Name, String Type, int HighTemp, int LowTemp, int HighHum, int LowHum, int SoilHum, String CropUrl) {
        CropData data = new CropData();
        data.setCropName(Name);
        data.setCropType(Type);
        data.setCropHighTemp(HighTemp);
        data.setCropLowTemp(LowTemp);
        data.setCropHighHum(HighHum);
        data.setCropLowHum(LowHum);
        data.setCropSoilHum(SoilHum);
        data.setCropImageUrl(CropUrl);
        Clist.add(data);
    }

    public void addItem_Herb(String Name, String Type, int HighTemp, int LowTemp, int HighHum, int LowHum, int SoilHum, String CropUrl) {
        CropData data = new CropData();
        data.setCropName(Name);
        data.setCropType(Type);
        data.setCropHighTemp(HighTemp);
        data.setCropLowTemp(LowTemp);
        data.setCropHighHum(HighHum);
        data.setCropLowHum(LowHum);
        data.setCropSoilHum(SoilHum);
        data.setCropImageUrl(CropUrl);
        Hlist.add(data);
    }

    public void addItem_Fruit(String Name, String Type, int HighTemp, int LowTemp, int HighHum, int LowHum, int SoilHum, String CropUrl) {
        CropData data = new CropData();
        data.setCropName(Name);
        data.setCropType(Type);
        data.setCropHighTemp(HighTemp);
        data.setCropLowTemp(LowTemp);
        data.setCropHighHum(HighHum);
        data.setCropLowHum(LowHum);
        data.setCropSoilHum(SoilHum);
        data.setCropImageUrl(CropUrl);
        Flist.add(data);
    }
}