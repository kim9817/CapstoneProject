package com.example.smartfarmapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;

public class showdata extends AppCompatActivity {

    int internet = 0;

    String Name;
    String Image;
    int HighTemp;
    int LowTemp;
    int HighHum;
    int LowHum;
    int SoilHum;


    EditText NameEdit;
    EditText LowTempEdit;
    EditText HighTempEdit;
    EditText LowHumEdit;
    EditText HighHumEdit;
    EditText SoilHumEdit;

    Button SaveButton;
    Button DeleteButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showdata);


        NameEdit = findViewById(R.id.NameEdit);
        LowTempEdit = findViewById(R.id.LowTempEdit);
        HighTempEdit = findViewById(R.id.HighTempEdit);
        LowHumEdit = findViewById(R.id.LowHumEdit);
        HighHumEdit = findViewById(R.id.HighHumEdit);
        SoilHumEdit = findViewById(R.id.SoilHumEdit);

        SaveButton = findViewById(R.id.SaveButton);
        DeleteButton = findViewById(R.id.DeleteButton);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference Check = database.getReference("Check");
        DatabaseReference F_HighTemp = database.getReference("HighTemp");
        DatabaseReference F_LowTemp = database.getReference("LowTemp");
        DatabaseReference F_HighHum = database.getReference("HighHum");
        DatabaseReference F_LowHum = database.getReference("LowHum");
        DatabaseReference F_SaveSoilMos = database.getReference("SaveSoilMos");
        DatabaseReference F_Change = database.getReference("Change");

        Check.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                internet = snapshot.getValue(int.class);
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        Intent intent = getIntent();
        String name = intent.getStringExtra("msg");
        int cmd =  Integer.parseInt(intent.getStringExtra("cmd"));

        CropDB helper = new CropDB(this);
        SQLiteDatabase Cropdb = helper.getWritableDatabase();
        if(cmd == 1) {
            String sql = "select * from Crop where Name = " + "'" + name + "';";
            Cursor cursor = Cropdb.rawQuery(sql, null);
            if (cursor.moveToFirst()) {
                Name = cursor.getString(1);
                Image = cursor.getString(2);
                HighTemp = cursor.getInt(4);
                LowTemp = cursor.getInt(5);
                HighHum = cursor.getInt(6);
                LowHum = cursor.getInt(7);
                SoilHum = cursor.getInt(8);

                NameEdit.setText(Name);
                LowTempEdit.setText(Integer.toString(LowTemp));
                HighTempEdit.setText(Integer.toString(HighTemp));
                LowHumEdit.setText(Integer.toString(LowHum));
                HighHumEdit.setText(Integer.toString(HighHum));
                SoilHumEdit.setText(Integer.toString(SoilHum));
            }
        }

        SaveDB SaveDBhelper = new SaveDB(this);
        SQLiteDatabase Savedb = SaveDBhelper.getWritableDatabase();
        if(cmd == 2) {
            DeleteButton.setVisibility(View.VISIBLE);
            String sql = "select * from Save where Name = " + "'" + name + "';";
            Cursor cursor1 = Savedb.rawQuery(sql, null);
            if (cursor1.moveToFirst()) {
                Name = cursor1.getString(1);
                Image = cursor1.getString(2);
                HighTemp = cursor1.getInt(4);
                LowTemp = cursor1.getInt(5);
                HighHum = cursor1.getInt(6);
                LowHum = cursor1.getInt(7);
                SoilHum = cursor1.getInt(8);

                NameEdit.setText(Name);
                LowTempEdit.setText(Integer.toString(LowTemp));
                HighTempEdit.setText(Integer.toString(HighTemp));
                LowHumEdit.setText(Integer.toString(LowHum));
                HighHumEdit.setText(Integer.toString(HighHum));
                SoilHumEdit.setText(Integer.toString(SoilHum));
            }
        }

        SaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int HT =  Integer.parseInt(HighTempEdit.getText().toString().trim()) ;
                int LT =  Integer.parseInt(LowTempEdit.getText().toString().trim()) ;
                int HH =  Integer.parseInt(HighHumEdit.getText().toString().trim()) ;
                int LH =  Integer.parseInt(LowHumEdit.getText().toString().trim()) ;
                int name_length = NameEdit.length();


                if(internet == 1){
                    if(name_length > 0 && HT > LT && HH > LH) {
                        if (cmd == 1) {
                            Savedb.execSQL("Insert into Save (Name, Image, HighTemp, LowTemp, HighHum, LowHum, FarmSoilHum) values(" +
                                    "'" + NameEdit.getText().toString() + "'," +
                                    "'" + Image + "'," +
                                    "'" + Integer.parseInt(HighTempEdit.getText().toString()) + "'," +
                                    "'" + Integer.parseInt(LowTempEdit.getText().toString()) + "'," +
                                    "'" + Integer.parseInt(HighHumEdit.getText().toString()) + "'," +
                                    "'" + Integer.parseInt(LowHumEdit.getText().toString()) + "'," +
                                    "'" + Integer.parseInt(SoilHumEdit.getText().toString()) + "');"
                            );
                            F_HighTemp.setValue(Integer.parseInt(HighTempEdit.getText().toString()));
                            F_LowTemp.setValue(Integer.parseInt(LowTempEdit.getText().toString()));
                            F_HighHum.setValue(Integer.parseInt(HighHumEdit.getText().toString()));
                            F_LowHum.setValue(Integer.parseInt(LowHumEdit.getText().toString()));
                            F_SaveSoilMos.setValue(Integer.parseInt(SoilHumEdit.getText().toString()));
                            F_Change.setValue(1);
                            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
                            long now = System.currentTimeMillis();
                            String getTime = sdf1.format(now);
                            saveState(getTime);
                            Toast.makeText(showdata.this, "insert 성공", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                        if (cmd == 2) {
                            Savedb.execSQL("Delete from Save where Name = " + "'" + name + "';");
                            Savedb.execSQL("Insert into Save (Name, Image, HighTemp, LowTemp, HighHum, LowHum, FarmSoilHum) values(" +
                                    "'" + NameEdit.getText().toString() + "'," +
                                    "'" + Image + "'," +
                                    "'" + Integer.parseInt(HighTempEdit.getText().toString()) + "'," +
                                    "'" + Integer.parseInt(LowTempEdit.getText().toString()) + "'," +
                                    "'" + Integer.parseInt(HighHumEdit.getText().toString()) + "'," +
                                    "'" + Integer.parseInt(LowHumEdit.getText().toString()) + "'," +
                                    "'" + Integer.parseInt(SoilHumEdit.getText().toString()) + "');"
                            );
                            F_HighTemp.setValue(Integer.parseInt(HighTempEdit.getText().toString()));
                            F_LowTemp.setValue(Integer.parseInt(LowTempEdit.getText().toString()));
                            F_HighHum.setValue(Integer.parseInt(HighHumEdit.getText().toString()));
                            F_LowHum.setValue(Integer.parseInt(LowHumEdit.getText().toString()));
                            F_SaveSoilMos.setValue(Integer.parseInt(SoilHumEdit.getText().toString()));
                            F_Change.setValue(1);
                            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
                            long now = System.currentTimeMillis();
                            String getTime = sdf1.format(now);
                            saveState(getTime);
                            Toast.makeText(showdata.this, "Update 성공", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                    else{
                        Toast.makeText(showdata.this, "입력값을 확인해주세요.", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(showdata.this, "인터넷 연결을 확인해주세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        DeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Savedb.execSQL("Delete from Save where Name = " + "'" + NameEdit.getText().toString() + "';");
                Toast.makeText(showdata.this, "Delete 성공", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
    protected void saveState(String Date){
        SharedPreferences pref = getSharedPreferences("Date", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("Date", Date);
        editor.commit();
    }

}

