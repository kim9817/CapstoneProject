package com.example.smartfarmapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    Button RegisterCropButton;
    Button SettingButton;
    ImageView SettingImage;

    ImageView CropImage;
    TextView CropName;
    TextView CropTemp;
    TextView CropHum;
    TextView CropSoilHum;

//###############################
    TextView OutTempText;
    TextView OutHumText;
    TextView InTempText;
    TextView InHumText;
    TextView SoilMosText;
    TextView DateText;

    TextView WarningText;

    ConstraintLayout ImageLayout;

//##############################
    int internet = 0;
    Button Sensor_Button;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference Check = database.getReference("Check");
    DatabaseReference InTemp = database.getReference("InTemp");
    DatabaseReference InHum = database.getReference("InHum");
    DatabaseReference OutTemp = database.getReference("OutTemp");
    DatabaseReference OutHum = database.getReference("OutHum");
    DatabaseReference SoilMos = database.getReference("SoilMos");
    DatabaseReference SetMode = database.getReference("Mode");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RegisterCropButton = findViewById(R.id.RegisterCropButton);
        SettingButton = findViewById(R.id.SettingButton);
        SettingImage = findViewById(R.id.SettingImage);
        CropImage = findViewById(R.id.CropImage);

        CropName = findViewById(R.id.CropName);
        CropTemp = findViewById(R.id.CropTemp);
        CropHum = findViewById(R.id.CropHum);
        CropSoilHum = findViewById(R.id.CropSoilHum);

        InTempText = findViewById(R.id.InTempText);
        InHumText = findViewById(R.id.InHumText);
        DateText =findViewById(R.id.DateText);

        OutTempText = findViewById(R.id.OutTempText);
        OutHumText = findViewById(R.id.OutHumText);
        SoilMosText = findViewById(R.id.SoilMos);
        ImageLayout =findViewById(R.id.ImageLayout);

        WarningText = findViewById(R.id.WarningText);

        SettingButton.bringToFront();
        SettingImage.bringToFront();

        Sensor_Button = findViewById(R.id.Sensor_Button);

        SaveDB helper = new SaveDB(this);
        SQLiteDatabase Savedb = helper.getWritableDatabase();
        String sql = "select * from Save;";
        Cursor cursor = Savedb.rawQuery(sql, null);
            if (cursor.moveToFirst()) {
                RegisterCropButton.setVisibility(View.INVISIBLE);
                String Name = cursor.getString(1);
                String Image = cursor.getString(2);
                int HighTemp = cursor.getInt(4);
                int LowTemp = cursor.getInt(5);
                int HighHum = cursor.getInt(6);
                int LowHum = cursor.getInt(7);
                int SoilHum = cursor.getInt(8);
                //RegisterCropButton.setVisibility(View.INVISIBLE);
                RegisterCropButton.setText("");
                SettingButton.setVisibility(View.VISIBLE);
                SettingButton.setEnabled(true);
                SettingImage.setVisibility(View.VISIBLE);
                CropImage.setVisibility(View.VISIBLE);
                ImageLayout.setVisibility(View.VISIBLE);
                DateText.setVisibility(View.VISIBLE);
                DateText.setText(checkFile());
                Glide.with(this).load(Image).into(CropImage);
                CropName.setVisibility(View.VISIBLE);
                CropName.setText(Name);
                CropTemp.setVisibility(View.VISIBLE);
                CropTemp.setText("온도: " + LowTemp + "~" + HighTemp + "°C");
                CropHum.setVisibility(View.VISIBLE);
                CropHum.setText("습도: " + LowHum + "~" + HighHum + "%");
                CropSoilHum.setVisibility(View.VISIBLE);
                CropSoilHum.setText("토양수분: " + SoilHum + "%");
            }

        RegisterCropButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SelectCrop.class);
                startActivity(intent);
            }
        });

        SettingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), showdata.class);
                intent.putExtra("msg", CropName.getText().toString());
                intent.putExtra("cmd", "2");
                startActivity(intent);
            }
        });

        Check.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                internet = snapshot.getValue(int.class);
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        InTemp.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                InTempText.setText(Integer.toString(value) + "°C");
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        InHum.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                InHumText.setText(Integer.toString(value) + "%");
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        OutTemp.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                if(value > 30){
                    WarningText.setVisibility(View.VISIBLE);
                }
                else{
                    WarningText.setVisibility(View.INVISIBLE);
                }

                OutTempText.setText(Integer.toString(value) + "°C");
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

       OutHum.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                OutHumText.setText(Integer.toString(value) + "%");
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        SoilMos.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                SoilMosText.setText(Integer.toString(value) + "%");
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        Sensor_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(internet == 1) {
                    Intent intent = new Intent(getApplicationContext(), SensorActivity.class);
                    startActivity(intent);
                    SetMode.setValue(1);
                    Toast.makeText(MainActivity.this, "수동제어를 시작합니다.", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "인터넷 연결을 확인해주세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    @Override
    protected void onResume(){
        super.onResume();
        setContentView(R.layout.activity_main);

        RegisterCropButton = findViewById(R.id.RegisterCropButton);
        SettingButton = findViewById(R.id.SettingButton);
        SettingImage = findViewById(R.id.SettingImage);
        CropImage = findViewById(R.id.CropImage);

        CropName = findViewById(R.id.CropName);
        CropTemp = findViewById(R.id.CropTemp);
        CropHum = findViewById(R.id.CropHum);
        CropSoilHum = findViewById(R.id.CropSoilHum);

        InTempText = findViewById(R.id.InTempText);
        InHumText = findViewById(R.id.InHumText);
        DateText =findViewById(R.id.DateText);

        OutTempText = findViewById(R.id.OutTempText);
        OutHumText = findViewById(R.id.OutHumText);
        SoilMosText = findViewById(R.id.SoilMos);
        ImageLayout =findViewById(R.id.ImageLayout);

        WarningText = findViewById(R.id.WarningText);

        SettingButton.bringToFront();
        SettingImage.bringToFront();

        Sensor_Button = findViewById(R.id.Sensor_Button);

        SaveDB helper = new SaveDB(this);
        SQLiteDatabase Savedb = helper.getWritableDatabase();
        String sql = "select * from Save;";
        Cursor cursor = Savedb.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            RegisterCropButton.setVisibility(View.INVISIBLE);
            String Name = cursor.getString(1);
            String Image = cursor.getString(2);
            int HighTemp = cursor.getInt(4);
            int LowTemp = cursor.getInt(5);
            int HighHum = cursor.getInt(6);
            int LowHum = cursor.getInt(7);
            int SoilHum = cursor.getInt(8);
            //RegisterCropButton.setVisibility(View.INVISIBLE);
            RegisterCropButton.setText("");
            SettingButton.setVisibility(View.VISIBLE);
            SettingButton.setEnabled(true);
            SettingImage.setVisibility(View.VISIBLE);
            CropImage.setVisibility(View.VISIBLE);
            ImageLayout.setVisibility(View.VISIBLE);
            DateText.setVisibility(View.VISIBLE);
            DateText.setText(checkFile());
            Glide.with(this).load(Image).into(CropImage);
            CropName.setVisibility(View.VISIBLE);
            CropName.setText(Name);
            CropTemp.setVisibility(View.VISIBLE);
            CropTemp.setText("온도: " + LowTemp + "~" + HighTemp + "°C");
            CropHum.setVisibility(View.VISIBLE);
            CropHum.setText("습도: " + LowHum + "~" + HighHum + "%");
            CropSoilHum.setVisibility(View.VISIBLE);
            CropSoilHum.setText("토양수분: " + SoilHum + "%");
        }

        RegisterCropButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SelectCrop.class);
                startActivity(intent);
            }
        });

        SettingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), showdata.class);
                intent.putExtra("msg", CropName.getText().toString());
                intent.putExtra("cmd", "2");
                startActivity(intent);
            }
        });

        Check.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                internet = snapshot.getValue(int.class);
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        InTemp.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                InTempText.setText(Integer.toString(value) + "°C");
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        InHum.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                InHumText.setText(Integer.toString(value) + "%");
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        OutTemp.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                if(value > 30){
                    WarningText.setVisibility(View.VISIBLE);
                }
                else{
                    WarningText.setVisibility(View.INVISIBLE);
                }

                OutTempText.setText(Integer.toString(value) + "°C");
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        OutHum.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                OutHumText.setText(Integer.toString(value) + "%");
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        SoilMos.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int value = snapshot.getValue(int.class);
                SoilMosText.setText(Integer.toString(value) + "%");
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        Sensor_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(internet == 1) {
                    Intent intent = new Intent(getApplicationContext(), SensorActivity.class);
                    startActivity(intent);
                    SetMode.setValue(1);
                    Toast.makeText(MainActivity.this, "수동제어를 시작합니다.", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "인터넷 연결을 확인해주세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }//Resume


    protected String checkFile(){
        SharedPreferences pref = getSharedPreferences("Date", Activity.MODE_PRIVATE);
        String a = "";
        if ((pref != null) && (pref.contains("Date"))){
            a = pref.getString("Date","");
        }
            return a;
    }
}