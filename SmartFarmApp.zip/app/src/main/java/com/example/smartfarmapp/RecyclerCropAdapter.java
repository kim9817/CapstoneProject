package com.example.smartfarmapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.signature.ObjectKey;

import java.util.ArrayList;

public class RecyclerCropAdapter extends RecyclerView.Adapter<RecyclerCropAdapter.ViewHolder> {
    public class ViewHolder extends RecyclerView.ViewHolder{
        Button Crop_Button;
        ImageView Crop_Image;
        TextView Crop_Name;
        TextView Crop_Type;
        TextView Crop_Temp;
        TextView Crop_Hum;
        TextView Crop_Soil_Hum;

        public ViewHolder(View itemView){
            super(itemView);
            Crop_Button = (Button) itemView.findViewById(R.id.Crop_Button);
            Crop_Image = itemView.findViewById(R.id.Crop_Image);
            Crop_Name = itemView.findViewById(R.id.Crop_Name);
            Crop_Type = itemView.findViewById(R.id.Crop_Type);
            Crop_Temp = itemView.findViewById(R.id.Crop_Temp);
            Crop_Hum = itemView.findViewById(R.id.Crop_Hum);
            Crop_Soil_Hum = itemView.findViewById(R.id.Crop_Soil_Hum);
        }
    }

    private ArrayList<CropData> Clist = null;

    public RecyclerCropAdapter(ArrayList<CropData> Clist) {this.Clist = Clist;}

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View view = inflater.inflate(R.layout.crop_adapter, parent, false);
        RecyclerCropAdapter.ViewHolder vh = new RecyclerCropAdapter.ViewHolder(view);
        return vh;
    }

    public void onBindViewHolder(RecyclerCropAdapter.ViewHolder holder, int position) {
        CropData item = Clist.get(position);
        holder.Crop_Name.setText(item.getCropName());
        holder.Crop_Type.setText(item.getCropType());
        holder.Crop_Temp.setText("온도: "+ item.getCropLowTemp() + "~" + item.getCropHighTemp() + "°C");
        holder.Crop_Hum.setText("습도: " + item.getCropLowHum() + "~" + item.getCropHighHum() + "%");
        holder.Crop_Soil_Hum.setText("토양습도: "+ item.getCropSoilHum() + "%");
        Glide.with(holder.itemView).load(item.getCropImageUrl()).apply(new RequestOptions().signature(new ObjectKey("signature string")).skipMemoryCache(true).diskCacheStrategy(DiskCacheStrategy.NONE)).into(holder.Crop_Image);

        holder.Crop_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = view.getContext();
                Intent intent = new Intent(view.getContext(), showdata.class);
                intent.putExtra("msg", item.getCropName());
                intent.putExtra("cmd", "1");
                context.startActivity(intent);
                ((Activity)context).finish();
            }
        });
    }

    public int getItemCount() {
        return Clist.size();
    }

}

